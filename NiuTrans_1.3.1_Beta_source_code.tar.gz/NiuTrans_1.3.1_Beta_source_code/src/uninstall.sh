#!/bin/bash

# remove all intermediate object files (*.o) and target binary files
make clean

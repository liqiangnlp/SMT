while(<STDIN>){
	chomp();
	print $_." |||| \n";
	print '================'."\n";
}